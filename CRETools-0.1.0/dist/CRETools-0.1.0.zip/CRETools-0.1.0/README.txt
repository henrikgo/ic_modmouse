To build:

python setup.py sdist

To install:

python setup.py install

Requirements:
numpy, scipy, datetime
